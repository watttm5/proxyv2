/**
 * Created by stryker on 2014.03.23..
 */
/*
 * Build script
 * To use: npm install -g require.js
 * r.js -o built.js
 * */

({
    baseUrl: ".",
    name: "main",
    out: "built/main-built.js"
})