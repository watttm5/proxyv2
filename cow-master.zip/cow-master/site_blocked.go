package main

var blockedDomainList = []string{
	"bit.ly",
	"j.mp",
	"bitly.com",
	"fbcdn.net",
	"facebook.com",
	"plus.google.com",
	"plusone.google.com",
	"t.co",
	"twimg.com",
	"twitpic.com",
	"twitter.com",
	"youtu.be",
	"youtube.com",
	"ytimg.com",
}
