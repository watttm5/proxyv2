# About cow-taskbar.exe

Copied `goagent.exe`, modified the string table and icon using reshack.

Thanks for the taskbar project created by @phuslu.

# About cow-hide.exe

Allow you to run COW as a background process, without any notifications. Provided by @xupefei's [cow-hide](https://github.com/xupefei/cow-hide) project.

Icon from [IconArchive](http://www.iconarchive.com/show/animal-icons-by-martin-berube/cow-icon.html), thanks to the author Martin Berube.

